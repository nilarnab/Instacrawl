from django.contrib import admin
from home.models import Accounts, Resource

# Register your models here.
admin.site.register(Accounts)
admin.site.register(Resource)